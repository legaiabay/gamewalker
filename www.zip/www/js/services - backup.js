angular.module('gamewalker.services', [])

.factory('Userdata', function(){
  var userList = [{
    id : 0,
    user : 'a',
    pass : 'a',
    email : 'a',
    avatar : "img/gue.jpg"
  },{
    id : 1,
    user : 'admin',
    pass : 'admin',
    email : 'admin@admin.com',
    avatar : "img/gue.jpg",
    admin : true
  }];
  
  var userLogin = [];

  return{
    get: function(){
      return userLogin;
    },
    getList: function(){
      return userList;
    }
  }
})

.factory('Games', function(){

  var games = [{
    id : 0,
    name : 'Terra Battle',
    desc : 'Terra Battle (テラバトル) is a mobile video game developed by Mistwalker, the company of Final Fantasy creator Hironobu Sakaguchi. It was released for the iOS and Android platforms on October 9, 2014. Kimihiko Fujisaka served as the main character designer, with other character and monster designs being done by Hideo Minaba, Nakaba Suzuki, Hitoshi Yoneda, Manabu Kusunoki, Naoto Ohshima, Ami Shibata, and Yoshitaka Amano.',
    image : 'img/terra-battle_cover.jpg',
    link : 'http://terra-battle.com'
  }, {
    id : 1,
    name : 'Granblue Fantasy',
    desc : 'Granblue Fantasy (グランブルーファンタジー Guranburū Fantajī?) is a role-playing video game developed by Cygames for Android and iOS platforms, which first released in Japan in March 2014. The game is notable for reuniting music composer Nobuo Uematsu and art director Hideo Minaba, who also worked on Final Fantasy VI (1994), Final Fantasy IX (2000), and Lost Odyssey (2007) together.',
    image : 'img/granblue-fantasy_cover.jpg',
    link : 'http://granbluefantasy.jp'
  }, {
    id : 2,
    name : 'Fate Grand Order',
    desc : 'Fate/Grand Order (フェイト/グランドオーダー, Feito/Gurando Ōdā?) is an online RPG for iOS and Android. Referred to as the "Fate Online Project Reboot", it is a reboot of the original Fate/Apocrypha project that eventually became a novel series.',
    image : 'img/fate-go_cover.jpg',
    link : 'http://fate-go.jp'
  }];

  return{
    all: function(){
      return games;
    },
    get: function(gameId) {
      for (var i = 0; i < games.length; i++) {
        if (games[i].id === parseInt(gameId)) {
          return games[i];
        }
      }
      return null;
    }
  };
})

.factory('Forum', function(){
  var post = [{
    id : 0,
    name : 'Terra Battle',
    question : [{
      id : 0,
      title : 'Cara reroll',
      askmore : "ampas bgt ane tadi ngegacha. pengen reroll aja. gimana yak caranya?",
      by : 'a',
      avatar : "img/gue.jpg",
      time : '30 minutes ago',
      answer : [{
        id : 0,
        by : 'a',
        avatar : "img/gue.jpg",
        answer : 'Ga tau deh kk, kali aja yg bawah tau'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'Pernah coba tapi lupa heheh'
      },{
        id : 2,
        by : 'Turtle',
        avatar : "img/gue.jpg",
        answer : 'Clear data dulu gan, nanti baru bisa bikin baru'
      }]
    },{
      id : 1,
      title : 'Cara main',
      askmore : "Ane udah main 2 jam tapi ga ngerti2. ajarin dong sepuh!",
      by : 'Legaiabay',
      avatar : "img/gue.jpg",
      time : '40 minutes ago',
      answer : [{
        id : 0,
        by : 'Dog',
        avatar : "img/gue.jpg",
        answer : 'Sok tau lu'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'kan tinggal geser aja gan'
      }]
    }]},{
    id : 1,
    name : 'Granblue Fantasy',
    question : [{
      id : 0,
      title : 'Cara reroll granblue',
      askmore : "ampas bgt ane tadi ngegacha granblue. pengen reroll aja. gimana yak caranya?",
      by : 'Legaiabay',
      avatar : "img/gue.jpg",
      time : '30 minutes ago',
      answer : [{
        id : 0,
        by : 'Dog',
        avatar : "img/gue.jpg",
        answer : 'Ga tau deh kk, kali aja yg bawah tau'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'Pernah coba tapi lupa heheh'
      },{
        id : 2,
        by : 'Turtle',
        avatar : "img/gue.jpg",
        answer : 'Clear data dulu gan, nanti baru bisa bikin baru'
      }]
    },{
      id : 1,
      title : 'Cara main',
      askmore : "Ane udah main 2 jam tapi ga ngerti2. ajarin dong sepuh!",
      by : 'Legaiabay', 
      avatar : "img/gue.jpg",
      time : '40 minutes ago',
      answer : [{
        id : 0,
        by : 'Dog',
        avatar : "img/gue.jpg",
        answer : 'Sok tau lu'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'kan tinggal geser aja gan'
      }]
    }]},{
    id : 2,
    name : 'Fate Grand Order',
    question : [{
      id : 0,
      title : 'Cara reroll fgo',
      askmore : "ampas bgt ane tadi ngegacha fgi. pengen reroll aja. gimana yak caranya?",
      by : 'Legaiabay',
      avatar : "img/gue.jpg",
      time : '30 minutes ago',
      answer : [{
        id : 0,
        by : 'Dog',
        avatar : "img/gue.jpg",
        answer : 'Ga tau deh kk fgo, kali aja yg bawah tau'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'Pernah coba tapi lupa heheh'
      },{
        id : 2,
        by : 'Turtle',
        avatar : "img/gue.jpg",
        answer : 'Clear data dulu gan, nanti baru bisa bikin baru'
      }]
    },{
      id : 1,
      title : 'Cara main',
      askmore : "Ane udah main 2 jam tapi ga ngerti2. ajarin dong sepuh!",
      by : 'Legaiabay',
      avatar : "img/gue.jpg",
      time : '40 minutes ago',
      answer : [{
        id : 0,
        by : 'Dog',
        avatar : "img/gue.jpg",
        answer : 'Sok tau lu'
      },{
        id : 1,
        by : 'Cat',
        avatar : "img/gue.jpg",
        answer : 'kan tinggal geser aja gan'
      }]
    }]}
  ];

  var guide = [{
    id : 0,
    name : 'Terra Battle',
    guide : [{
      id : 0,
      title : 'Cara farm coin',
      guidepost : 'Caranya : Farm di Coin Creeps tiap Sabtu/Minggu. Pake Lacuma karena punya coin boost 30%.',
      by : 'a',
      avatar : "img/gue.jpg",
      time : 'Now',
      answer : []
    },{
      id : 1,
      title : 'Cara ngalahin Shinen',
      guidepost : 'Pake Mizell',
      by : 'Legaiabay',
      avatar : "img/gue.jpg",
      time : 'Now',
      answer : []
    }]
  },{
    id : 1,
    name : 'Granblue Fantasy',
    guide : []
  },{
    id : 2,
    name : 'Fate Grand Order',
    guide : []
  } ];

  return{
    all: function(){
      return post;
    },
    get: function(forumId) {
      for (var i = 0; i < post.length; i++) {
        if (post[i].id === parseInt(forumId)) {
          return post[i];
        }
      }
      return null;
    },
    allguide : function(){
      return guide;
    },
    getguide : function(forumId) {
      for (var i = 0; i < guide.length; i++) {
        if (guide[i].id === parseInt(forumId)) {
          return guide[i];
        }
      }
      return null;
    }
  };
})

;
