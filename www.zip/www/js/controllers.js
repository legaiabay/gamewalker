angular.module('gamewalker.controllers', ['firebase'])

.controller('tabsCtrl', function($scope, $rootScope){

  $rootScope.$on('ShowTabs', function(){
    $scope.hide(false);  
  });

  $rootScope.$on('HideTabs', function(){
    $scope.hide(true);  
  });

  $scope.tabhide = "tabs-item-hide";

  $scope.hide = function(hide){
    if(hide == true){$scope.tabhide = "tabs-item-hide"}
    else {$scope.tabhide = ""}
  }
})

.controller('loginCtrl', function($scope, $window,$rootScope, $ionicLoading, $state, $ionicHistory, Userdata) {

  $ionicLoading.show({
      template: '<p>Sign In...</p><ion-spinner></ion-spinner>'
    });

  firebase.auth().onAuthStateChanged(function(currentUser) {
    
    console.log(currentUser);
    if(currentUser){
      //alert(currentUser.displayName);
      moveToGames();
      $ionicLoading.hide();
    }
    else {
      $ionicLoading.hide();
    }
  });

  $scope.height = $window.innerHeight;
  $scope.headerHide = "false";

  var moveToGames = function(){
    $ionicHistory.nextViewOptions({
      disableBack: true
    });
    $state.go('tab.games');
    $rootScope.$emit('ShowTabs', {});
  }

   $scope.reset = function(form){
      $scope.login = {};
  }

  $scope.loginsubmit = function(){
    $ionicLoading.show({
      template: '<p>Sign In...</p><ion-spinner></ion-spinner>'
    });
    //$scope.login.username
    //$scope.login.password

    firebase.auth().signInWithEmailAndPassword(
      $scope.login.username,
      $scope.login.password

    ).then(function(){
      moveToGames();
      $scope.reset();
      //$ionicHistory.clearHistory();
      //$ionicHistory.clearCache();
    }).catch(function(error){
      alert(error.message);
    })
  }

  
})

.controller('loginRegisterCtrl', function($scope,$rootScope,$state,$ionicHistory,$window,Userdata){
  $scope.height = $window.innerHeight;
  
 //console.log(defaultImage);
  //var reff = imageRef.child('image-user/user-default.png');

  //user : $scope.user,
  
  //pass : $scope.pass,
  //email : $scope.email,
  
  $scope.registersubmit = function(){
    var usermail = $scope.email;
    var userpass = $scope.pass;
    var useruser = $scope.user;

    firebase.auth().createUserWithEmailAndPassword(
      usermail, userpass
    ).then(function(newuser){
      var defaultImage;
      console.log("REGIS SUKES");
      var imageRef = firebase.storage().ref('image-user/user-default.png').getDownloadURL().then(function(url){;
        console.log(url);
        alert("gambar default");
        defaultImage = url;

        newuser.updateProfile({
          displayName : useruser,
          photoURL : defaultImage
        });

        $ionicHistory.nextViewOptions({
          disableBack: true
        });
        $state.go('tab.games');
        $rootScope.$emit('ShowTabs', {});
      });
    }).catch(function(error){
      alert(error);
    });

    $scope.email = "";
    $scope.user = "";
    $scope.pass = "";
  }
})

.controller('GamesCtrl', function($scope, $firebaseArray, Games){
  $scope.games = Games.all();
  //console.log($scope.games);
})

.controller('GamesDetailCtrl', function($scope, $firebaseArray, $stateParams, Games){
  $scope.game = Games.get($stateParams.gameId);
})

.controller('ForumCtrl', function($scope, $firebaseArray, Games, Forum, Userdata){
  $scope.forums = Forum.all();
  $scope.games = Games.all();
  $scope.guides = Forum.allguide();  

  $scope.getLength = function(post){
    console.log(post);
    //console.log(post.length);
    var j = 0;
    if(post == undefined){
      j = 0;
    }
    else if(post.length == undefined){
      j = 1;
    }
    else {
      for(i=0;i<post.length;i++){
        if(post[i] != undefined){
          j++;
        }
      }
    }
    return j;
  }
})

.controller('ForumDetailCtrl', function($scope, $stateParams, Forum, Games){
  $scope.id = $stateParams.forumId;
  $scope.forum = Forum.get($stateParams.forumId);
  $scope.guide = Forum.getguide($stateParams.forumId);
  $scope.game = Games.get($stateParams.forumId);

  //var currentPost = $scope.forum.question;
  //console.log(currentPost);
})

.controller('ForumDetailAskCtrl', function($scope,$firebaseArray, $state, $ionicHistory, $stateParams, Forum, Games, Userdata){

  $scope.ask = Forum.get($stateParams.forumId);
  $scope.game = Games.get($stateParams.forumId);
  var currentPost = $scope.ask.question;
  console.log(currentPost);
  //console.log("Cek : " + currentPost[3].id + " = " + $stateParams.askId);
  //console.log("Tes lagi : " + $scope.ask.question["3"].by);
  var postKey = $scope.ask.$id;
  //console.log($stateParams.askId);
  $scope.editreply = {};
  $scope.editMode = false;
  $scope.editReplyMode = false;
  var replyId;
  
  $scope.id = $stateParams.askId.toString();

  console.log($scope.id);
  var user = Userdata.get();
  var postUser = $scope.ask.question[$scope.id].by;
  var currentUser = firebase.auth().currentUser.displayName;
  var answer = $scope.ask.question[$scope.id].answer;

  if(postUser == currentUser){$scope.allowEditPost = true;}
  else {$scope.allowEditPost = false;}

  $scope.getReplyUser = function(userr){
    if(userr == currentUser){return true}
    else {return false}
  }

  $scope.editPost = function(reply){
    $scope.editMode = true;
    //alert($scope.edittitle);
    var w = Forum.get($stateParams.forumId);
    var a = w.question;
    
    $scope.editposttitle = a[$scope.id].title;
    $scope.editposttext = a[$scope.id].askmore;

  }

  $scope.deletePost = function(reply, id){
    var postRef = '/forum/'+postKey+'/question/'+$scope.id;
    firebase.database().ref(postRef).remove();
    $ionicHistory.goBack();
  }

  $scope.editpostsubmit = function(){
    var postRef = '/forum/'+postKey+'/question/'+$scope.id;
    //alert($scope.edittitle);
    //currentPost[$scope.id].title = $scope.editposttitle;
    //currentPost[$scope.id].askmore = $scope.editposttext;

    firebase.database().ref(postRef).update({
      title : $scope.editposttitle,
      askmore : $scope.editposttext
    })

    $scope.ask = Forum.get($stateParams.forumId);

    $scope.editMode = false;
  }

  $scope.deletereplypost = function(id){

    console.log(id);

    var delref = '/forum/'+postKey+'/question/'+$scope.id+'/answer/'+id;
    firebase.database().ref(delref).remove()
    .then(function(data){
      console.log("REMOVE SUKESS");
    }).catch(function(error){
      console.log("ERROR : " + error);
    });

    //replyId = id;
    //answer.splice(replyId,1);
    //replyId = null;
    
    $scope.editMode = false;
    $scope.editReplyMode = false;
  }

  $scope.editreplypost = function(reply, id){
    replyId = id;
    //alert(id);
    $scope.editReplyMode = true;
    $scope.editreply.text = reply;
  }

  $scope.editreplyid = function(id){
    if(id == replyId){return true;}
    else {return false;}
  }

  $scope.editreplysubmit = function(id){
    //answer[id].answer = $scope.editreply.text;
    
    var editRef = '/forum/'+postKey+'/question/'+$scope.id+'/answer/'+id;
    firebase.database().ref(editRef).update({
      answer : $scope.editreply.text
    }).then(function(data){
      console.log("Edit Reply Sukses");
    }).catch(function(error){
      console.log("ERROR : " + error);
    });
    
    $scope.editReplyMode = false;
    replyId = null;
  }
  
  $scope.replysubmit = function(){
    var setId;
    var reff = firebase.database().ref('/forum/'+postKey+'/question/'+$scope.id+'/answer/');
    reff.on("value", function(snap){
      console.log(snap.val());
      if(snap.val() == null){
        setId = 0;
      } else {
        setId = snap.val().length;
      }
    })

    console.log(setId);

    var replyRef = '/forum/'+postKey+'/question/'+$scope.id+'/answer/'+setId;
    firebase.database().ref(replyRef).update({
      id : setId,
      by : firebase.auth().currentUser.displayName,
      avatar : firebase.auth().currentUser.photoURL,
      answer : $scope.reply.text
    }).then(function(data){
      console.log("Reply Sukses ");
    }).catch(function(error){
      console.log("ERROR : " + error);
    });

    $scope.reply.text = "";
  }

})

.controller('ForumDetailGuideCtrl', function($scope, $state, $firebaseArray, $stateParams, $ionicHistory, Forum, Games, Userdata){
  
  
  $scope.guide = Forum.getguide($stateParams.forumId);
  $scope.game = Games.get($stateParams.forumId);
  var currentGuide = $scope.guide.guide;
  var guideKey = $scope.guide.$id;
  $scope.editreply = {};
  $scope.editMode = false;
  $scope.editReplyMode = false;
  var replyId;
  //$scope.editReply = false;

  //CEK GUIDE COCOK SAMA PARAMETER ATO GA
  $scope.id = $stateParams.guideId.toString();
  
  var user = Userdata.get();
  var guideUser = $scope.guide.guide[$scope.id].by;
  var currentUser = firebase.auth().currentUser.displayName;
  var answer = $scope.guide.guide[$scope.id].answer;
  //alert("a");

  if(guideUser == currentUser){$scope.allowEditGuide = true;}
  else {$scope.allowEditGuide = false;}

  $scope.getReplyUser = function(userr){
    if(userr == currentUser){return true}
    else {return false}
  }

  $scope.editGuide = function(reply){
    $scope.editMode = true;
    //alert(currentGuide[$scope.id].title);
    var w = Forum.getguide($stateParams.forumId);
    var a = w.guide;

    $scope.editguidetitle = a[$scope.id].title;
    $scope.editguidetext = a[$scope.id].guidepost;
  }

  $scope.deleteGuide = function(reply, id){
    //reply.splice(id,1);
    var guideRef = '/guide/'+guideKey+'/guide/'+$scope.id;
    firebase.database().ref(guideRef).remove();
    $ionicHistory.goBack();
  }

  $scope.editguidesubmit = function(){
    var guideRef = '/guide/'+guideKey+'/guide/'+$scope.id;
    //alert($scope.edittitle);
    //currentGuide[$scope.id].title = $scope.editguidetitle;
    //currentGuide[$scope.id].guidepost = $scope.editguidetext;
    //$scope.editMode = false;
  
    firebase.database().ref(guideRef).update({
      title : $scope.editguidetitle,
      askmore : $scope.editguidetext
    });

    $scope.guide = Forum.getguide($stateParams.forumId);

    $scope.editMode = false;
  }

  $scope.deletereplyguide = function(id){
    
    console.log(id);

    var delref = '/guide/'+guideKey+'/guide/'+$scope.id+'/answer/'+id;
    firebase.database().ref(delref).remove()
    .then(function(data){
      console.log("REMOVE SUKSES");
    }).catch(function(error){
      console.log("ERROR : " + error);
    })
    
    //replyId = id;
    //answer.splice(replyId,1);
    //replyId = null;

    $scope.editMode = false;
    $scope.editReplyMode = false;
  }

  $scope.editreplyguide = function(reply, id){
    replyId = id;
    //alert(id);
    $scope.editReplyMode = true;
    //alert(replyId)
    $scope.editreply.text = reply;
  }

  $scope.editreplyid = function(id){
    if(id == replyId){return true;}
    else {return false;}
  }

  $scope.editreplysubmit = function(id){
    //answer[id].answer = $scope.editreply.text;
    
    var editRef = '/guide/'+guideKey+'/guide/'+$scope.id+'/answer/'+id;
    firebase.database().ref(editRef).update({
      answer : $scope.editreply.text
    }).then(function(data){
      console.log("Edit Reply Sukses");
    }).catch(function(error){
      console.log("ERROR : " + error);
    });

    $scope.editReplyMode = false;
    replyId = null;
  }

  $scope.replysubmit = function(){
    var setId;
    var reff = firebase.database().ref('/guide/'+guideKey+'/guide/'+$scope.id+'/answer/');
    reff.on("value", function(snap){
      console.log(snap.val());
      if(snap.val() == null){
        setId = 0;
      } else {
        setId = snap.val().length;
      }
    })

    console.log(setId);

    var replyRef = '/guide/'+guideKey+'/guide/'+$scope.id+'/answer/'+setId;
    firebase.database().ref(replyRef).update({
      id : setId,
      by : firebase.auth().currentUser.displayName,
      avatar : firebase.auth().currentUser.photoURL,
      answer : $scope.reply.text
    }).then(function(data){
      console.log("Reply Sukses " + data);
    }).catch(function(error){
      console.log("ERROR : " + error);
    });

    $scope.reply.text = "";
}
})

.controller('ForumNewPostCtrl', function($scope,$firebaseArray, $stateParams,$ionicHistory,Forum,Userdata){
 var postId = Forum.get($stateParams.forumId);
 var postKey = postId.$id;
 var questionId;
 if(postId.question == null){
   questionId = 0;
 }
 else {
   questionId = postId.question[postId.question.length-1].id++;
 }
 //var post = postId.question;
 //var questionId = post.length;
 //var user = Userdata.get();

  $scope.newpostsubmit = function(){
    var postRef = '/forum/'+postKey+'/question/'+questionId;

    //alert(questionId);
    //post.push({
    firebase.database().ref(postRef).update({
      id : questionId,
      title : $scope.newpost.title,
      askmore : $scope.newpost.text,
      by : firebase.auth().currentUser.displayName,
      avatar: firebase.auth().currentUser.photoURL,
      time : "Now",
      answer : []
    })
    .then(function(data){
      console.log("SUKSES " + data);
    }).catch(function(error){
        console.log("ERROR : " + error);
    });

    //alert("done2");
    $scope.newpost.title = "";
    $scope.newpost.text = "";
    $ionicHistory.goBack();
  }
})

.controller('ForumNewGuideCtrl', function($scope,$stateParams,$ionicHistory,Forum,Userdata){
 var guideId = Forum.getguide($stateParams.forumId);
 var guideKey = guideId.$id;
 var guideeId;
 if(guideId.guide == null){
   guideeId = 0;
 }
 else {
   guideeId = guideId.guide[guideId.guide.length-1].id++;
 }

 
 //var guide = guideId.guide;
 //var guideeId = guide.length;
 //var user = Userdata.get();

  $scope.newguidesubmit = function(){
    var guideRef = '/guide/'+guideKey+'/guide/'+guideeId;
    //alert(questionId);
    firebase.database().ref(guideRef).update({
      id : guideeId,
      title : $scope.newguide.title,
      guidepost : $scope.newguide.text,
      by : firebase.auth().currentUser.displayName,
      avatar: firebase.auth().currentUser.photoURL,
      time : "Now",
      answer : []
    }).then(function(data){
      console.log("SUKSES " + data);
    }).catch(function(error){
        console.log("ERROR : " + error);
    });

    //alert("done2");
    $scope.newguide.title = "";
    $scope.newguide.text = "";
    $ionicHistory.goBack();
  }
})

.controller('AccountCtrl', function($scope, $ionicPlatform, $ionicLoading, $cordovaImagePicker, $cordovaFile, $timeout, $state, $rootScope, $ionicHistory, Userdata) {

    var user = firebase.auth().currentUser;

    $scope.avatar = user.photoURL;
    $scope.id = user.uid;
    $scope.user = user.displayName;
  
    $scope.changeAvatar = function(){

      var option = {
        maximumImagesCount : 1,
        width : 500,
        quality : 80
      };

    var fileName, pathh;

    $cordovaImagePicker.getPictures(option)
      .then(function (results) {
        $ionicLoading.show({
          template: '<p>Uploading...</p><ion-spinner></ion-spinner>'
        });

        fileName = results[0].substr(results[0].lastIndexOf('/')+1);

        // modify the image path when on Android
        if ($ionicPlatform.is("android")) {
          pathh = cordova.file.cacheDirectory;
        } else {
          pathh = cordova.file.tempDirectory;
        }
        
        return $cordovaFile.readAsArrayBuffer(pathh, fileName);
        //alert("fil : " + fil);
      }).then(function(succ){
        var imageBlob = new Blob([succ], { type: "image/jpeg" });

        // missed some params... NOW it is a promise!!
        var uploadTask = firebase.storage().ref('/image-user/user_image_'+firebase.database().currentUser.uid+".jpg").put(imageBlob);
        
        uploadTask.on('state_changed', function(snapshot){
          //KOSOOOOONG
        }, function(error) {
          alert(error);
        }, function() {
          alert("alert");
          var downloadURL = uploadTask.snapshot.downloadURL;
          alert(downloadURL);

          firebase.auth().onAuthStateChanged(function(currentUser) {
            if(currentUser){
              currentUser.updateProfile({
                photoURL : downloadURL
              }).then(function(){
                $scope.avatar = downloadURL;
                $scope.$apply();
                $ionicLoading.hide();
                alert("Avatar changed successfully.");
              }).catch(function(error){
                $ionicLoading.hide();
                alert("ERROR DISINI : " + error)
              });
            }
          });
          
        });
      }).catch(function(error){
        alert(error);
      });
    }
  
  
  $scope.logout = function(){
    //var login = Userdata.get();
    //login.pop();
    firebase.auth().signOut()
    .then(function(){
      $ionicHistory.clearCache()
      .then(function(){
         $rootScope.$emit('HideTabs', {});
          $ionicHistory.nextViewOptions({
            disableBack: true
          });
          $ionicHistory.clearHistory();
          //console.log(firebase.auth().currentUser);
      });
      $state.go('tab.login');
    })
    .catch(function(error){
      console.log(error);
    });    
  }
})

;