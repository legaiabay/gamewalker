angular.module('gamewalker.services', ['firebase'])

.factory('Userdata', function(){
  var userList = [{
    id : 0,
    user : 'a',
    pass : 'a',
    email : 'a',
    avatar : "img/gue.jpg"
  },{
    id : 1,
    user : 'admin',
    pass : 'admin',
    email : 'admin@admin.com',
    avatar : "img/gue.jpg",
    admin : true
  }];
  
  var userLogin = [];

  return{
    get: function(){
      return userLogin;
    },
    getList: function(){
      return userList;
    }
  }
})

.factory('Games', function($firebaseArray){

  var games = $firebaseArray(firebase.database().ref("/games"));

  return{
    all: function(){
      return games;
    },
    get: function(gameId) {
        return games[gameId];
    }
  };
})

.factory('Forum', function($firebaseArray){
  var post = $firebaseArray(firebase.database().ref("/forum"));
  var guide = $firebaseArray(firebase.database().ref("/guide"));

  return{
    all: function(){
      return post;
    },
    get: function(forumId) {
      return post[forumId];
    },
    allguide : function(){
      return guide;
    },
    getguide : function(forumId) {
      return guide[forumId];
    }
  };
})

;
